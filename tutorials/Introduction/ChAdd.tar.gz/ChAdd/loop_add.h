#ifndef LOOP_ADD_H
#define LOOP_ADD_H

#define N 4

typedef int in_int_t;

float loop_add(in_int_t a[N]);

#endif // LOOP_ADD_H