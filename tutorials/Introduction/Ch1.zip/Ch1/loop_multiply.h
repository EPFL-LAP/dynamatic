#ifndef LOOP_MULTIPLY_H
#define LOOP_MULTIPLY_H

#define N 8

typedef int in_int_t;

#define NI 10
#define NJ 10
#define NK 10
#define NL 10

typedef int in_int_t;
typedef int out_int_t;
typedef int inout_int_t;

void loop_multiply(in_int_t alpha, inout_int_t tmp[NI][NJ]);

#endif // LOOP_MULTIPLY_H
