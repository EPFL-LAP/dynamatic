library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity handshake_constant_3 is
  generic (
    DATA_WIDTH : integer
  );
  port (
    clk, rst : in std_logic;
    -- input channel
    ctrl_valid : in  std_logic;
    ctrl_ready : out std_logic;
    -- output channel
    outs       : out std_logic_vector(DATA_WIDTH - 1 downto 0);
    outs_valid : out std_logic;
    outs_ready : in  std_logic
  );
end entity;

architecture arch of handshake_constant_3 is
begin
  outs       <= "11111111111111111111111111111111";
  outs_valid <= ctrl_valid;
  ctrl_ready <= outs_ready;
end architecture;
